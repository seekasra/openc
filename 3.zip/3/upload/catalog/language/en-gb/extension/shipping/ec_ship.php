<?php
// Text
$_['text_title']                               = 'EC-Ship';
$_['text_weight']                              = 'Weight:';
$_['text_air_registered_mail']                 = 'Air Registered Mail';
$_['text_air_parcel']                          = 'Air Parcel';
$_['text_e_express_service_to_us']             = 'e-Express Service to US';
$_['text_e_express_service_to_canada']         = 'e-Express Service to Canada';
$_['text_e_express_service_to_united_kingdom'] = 'e-Express Service to United Kingdom';
$_['text_e_express_service_to_russia']         = 'e-Express Service to Russia';
$_['text_e_express_service_one']               = 'e-Express service';
$_['text_e_express_service_two']               = 'e-Express service';
$_['text_speed_post']                          = 'SpeedPost (Standard Service)';
$_['text_smart_post']                          = 'Smart Post';
$_['text_local_courier_post']                  = 'Local Courier Post (Counter Collection)';
$_['text_local_parcel']                        = 'Local Parcel';

//error
$_['text_unavailable']                         = 'No shipping service available';
