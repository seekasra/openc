<?php
// Text
$_['text_subject']  = '%s - Affiliate Commission';
$_['text_received'] = 'Congratulations! You have received a commission payment from the %s affiliate program';
$_['text_amount']   = 'You have received:';
$_['text_total']    = 'Your total amount of commission is now:';